"use client";

import { useState, useMemo } from "react";
import { useAdminLogs } from "@/hooks/useAdminData";

export default function AdminLogsPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [timeFilter, setTimeFilter] = useState("");
  const [page, setPage] = useState(1);
  const limit = 10;

  // 构建查询参数
  const queryParams = useMemo(
    () => ({
      search: searchQuery || undefined,
      page,
      limit,
    }),
    [searchQuery, page]
  );

  // 获取日志数据
  const { logs, isLoading, error, pagination } = useAdminLogs(queryParams);

  // 格式化时间
  const formatDateTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return {
      date: date.toLocaleDateString("zh-CN", { year: "numeric", month: "2-digit", day: "2-digit" }),
      time: date.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
    };
  };

  // 获取操作类型徽章样式
  const getActionTypeBadge = (actionType: string) => {
    const actionMap: Record<string, { bg: string; text: string; darkBg: string; darkText: string; label: string }> = {
      MARKET_CREATE: {
        bg: "bg-blue-100",
        text: "text-blue-800",
        darkBg: "dark:bg-blue-900/30",
        darkText: "dark:text-blue-400",
        label: "创建市场",
      },
      MARKET_EDIT: {
        bg: "bg-purple-100",
        text: "text-purple-800",
        darkBg: "dark:bg-purple-900/30",
        darkText: "dark:text-purple-400",
        label: "编辑市场",
      },
      MARKET_RESOLVE: {
        bg: "bg-green-100",
        text: "text-green-800",
        darkBg: "dark:bg-green-900/30",
        darkText: "dark:text-green-400",
        label: "结算市场",
      },
      WITHDRAWAL_APPROVE: {
        bg: "bg-green-100",
        text: "text-green-800",
        darkBg: "dark:bg-green-900/30",
        darkText: "dark:text-green-400",
        label: "审批提现",
      },
      WITHDRAWAL_REJECT: {
        bg: "bg-red-100",
        text: "text-red-800",
        darkBg: "dark:bg-red-900/30",
        darkText: "dark:text-red-400",
        label: "拒绝提现",
      },
      USER_DISABLE: {
        bg: "bg-red-100",
        text: "text-red-800",
        darkBg: "dark:bg-red-900/30",
        darkText: "dark:text-red-400",
        label: "禁用用户",
      },
      USER_ENABLE: {
        bg: "bg-green-100",
        text: "text-green-800",
        darkBg: "dark:bg-green-900/30",
        darkText: "dark:text-green-400",
        label: "启用用户",
      },
      SETTINGS_UPDATE: {
        bg: "bg-orange-100",
        text: "text-orange-800",
        darkBg: "dark:bg-orange-900/30",
        darkText: "dark:text-orange-400",
        label: "更新设置",
      },
      DEPOSIT_VERIFY: {
        bg: "bg-cyan-100",
        text: "text-cyan-800",
        darkBg: "dark:bg-cyan-900/30",
        darkText: "dark:text-cyan-400",
        label: "验证充值",
      },
    };

    const style = actionMap[actionType] || {
      bg: "bg-gray-100",
      text: "text-gray-800",
      darkBg: "dark:bg-gray-900/30",
      darkText: "dark:text-gray-400",
      label: actionType,
    };
    return {
      className: `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${style.bg} ${style.text} ${style.darkBg} ${style.darkText}`,
      label: style.label,
    };
  };

  return (
    <div className="mx-auto max-w-[1400px] flex flex-col gap-6">
      {/* 页面标题 */}
      <div>
        <h1 className="text-2xl font-bold text-[#111418] dark:text-white">操作日志</h1>
        <p className="text-sm text-[#637588] dark:text-[#9da8b9] mt-1">查看所有管理员的操作记录和系统日志</p>
      </div>

      {/* 筛选区域 */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 bg-card-light dark:bg-card-dark p-4 rounded-xl border border-[#e5e7eb] dark:border-[#283545] shadow-sm">
        <div className="flex flex-col sm:flex-row gap-4 w-full lg:w-auto">
          {/* 搜索框 */}
          <div className="relative w-full sm:w-80">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <span className="material-symbols-outlined text-[#637588] dark:text-[#9da8b9]" style={{ fontSize: 20 }}>search</span>
            </div>
            <input
              className="block w-full pl-10 pr-3 py-2.5 border border-[#d1d5db] dark:border-[#3e4e63] rounded-lg leading-5 bg-white dark:bg-[#101822] text-[#111418] dark:text-white placeholder-[#9da8b9] focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary sm:text-sm"
              placeholder="搜索操作用户 / 动作..."
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {/* 时间筛选 */}
          <div className="relative w-full sm:w-48">
            <select
              className="block w-full pl-3 pr-10 py-2.5 border border-[#d1d5db] dark:border-[#3e4e63] rounded-lg leading-5 bg-white dark:bg-[#101822] text-[#111418] dark:text-white focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary sm:text-sm appearance-none"
              value={timeFilter}
              onChange={(e) => setTimeFilter(e.target.value)}
            >
              <option value="">全部时间</option>
              <option value="today">今天</option>
              <option value="week">最近7天</option>
              <option value="month">最近30天</option>
              <option value="custom">自定义范围</option>
            </select>
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
              <span className="material-symbols-outlined text-[#637588] dark:text-[#9da8b9]" style={{ fontSize: 20 }}>calendar_month</span>
            </div>
          </div>
        </div>

        {/* 操作按钮 */}
        <div className="flex gap-3 w-full lg:w-auto">
          <button className="flex items-center justify-center gap-2 px-4 py-2.5 bg-white dark:bg-[#101822] border border-[#d1d5db] dark:border-[#3e4e63] rounded-lg text-[#111418] dark:text-white hover:bg-[#f3f4f6] dark:hover:bg-[#283545] transition-colors text-sm font-medium w-full lg:w-auto">
            <span className="material-symbols-outlined" style={{ fontSize: 20 }}>filter_list</span>
            高级筛选
          </button>
          <button className="flex items-center justify-center gap-2 px-4 py-2.5 bg-primary text-white rounded-lg hover:bg-blue-600 transition-colors shadow-sm text-sm font-medium w-full lg:w-auto whitespace-nowrap">
            <span className="material-symbols-outlined" style={{ fontSize: 20 }}>download</span>
            导出日志
          </button>
        </div>
      </div>

      {/* 日志列表表格 */}
      <div className="bg-card-light dark:bg-card-dark rounded-xl border border-[#e5e7eb] dark:border-[#283545] shadow-sm overflow-hidden flex flex-col">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[#e5e7eb] dark:border-[#283545] bg-[#f9fafb] dark:bg-[#101822]">
                <th className="p-4 text-xs font-bold text-[#637588] dark:text-[#9da8b9] uppercase tracking-wider">ID</th>
                <th className="p-4 text-xs font-bold text-[#637588] dark:text-[#9da8b9] uppercase tracking-wider">时间戳</th>
                <th className="p-4 text-xs font-bold text-[#637588] dark:text-[#9da8b9] uppercase tracking-wider min-w-[150px]">操作用户</th>
                <th className="p-4 text-xs font-bold text-[#637588] dark:text-[#9da8b9] uppercase tracking-wider">动作类型</th>
                <th className="p-4 text-xs font-bold text-[#637588] dark:text-[#9da8b9] uppercase tracking-wider min-w-[300px]">详情</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e5e7eb] dark:divide-[#283545]">
              {/* 加载状态 */}
              {isLoading && (
                <tr>
                  <td colSpan={5} className="py-12 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                      <p className="text-[#637588] dark:text-[#9da8b9]">加载中...</p>
                    </div>
                  </td>
                </tr>
              )}

              {/* 错误状态 */}
              {error && !isLoading && (
                <tr>
                  <td colSpan={5} className="py-12 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <span className="material-symbols-outlined text-red-500" style={{ fontSize: 48 }}>
                        error
                      </span>
                      <p className="text-red-500">{error}</p>
                    </div>
                  </td>
                </tr>
              )}

              {/* 空状态 */}
              {!isLoading && !error && logs.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-12 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <span className="material-symbols-outlined text-[#637588] dark:text-[#9da8b9] opacity-50" style={{ fontSize: 48 }}>
                        manage_history
                      </span>
                      <div className="text-[#637588] dark:text-[#9da8b9]">
                        <p className="font-medium">暂无操作日志数据</p>
                      </div>
                    </div>
                  </td>
                </tr>
              )}

              {/* 数据行 */}
              {!isLoading &&
                !error &&
                logs.map((log) => {
                  const { date, time } = formatDateTime(log.timestamp);
                  const badge = getActionTypeBadge(log.actionType);
                  return (
                    <tr key={log.logId} className="hover:bg-[#f9fafb] dark:hover:bg-[#1e2a36] transition-colors group">
                      <td className="p-4">
                        <span className="text-sm font-medium text-[#111418] dark:text-white font-mono">#{log.logId}</span>
                      </td>
                      <td className="p-4">
                        <div className="flex flex-col">
                          <span className="text-sm text-[#111418] dark:text-white">{date}</span>
                          <span className="text-xs text-[#637588] dark:text-[#9da8b9]">{time}</span>
                        </div>
                      </td>
                      <td className="p-4">
                        <span className="text-sm font-medium text-[#111418] dark:text-white">{log.adminUsername}</span>
                      </td>
                      <td className="p-4">
                        <span className={badge.className}>{badge.label}</span>
                      </td>
                      <td className="p-4">
                        <span className="text-sm text-[#111418] dark:text-white">{log.details}</span>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>

        {/* 分页 */}
        {!isLoading && !error && (
          <div className="flex items-center justify-between p-4 border-t border-[#e5e7eb] dark:border-[#283545] bg-card-light dark:bg-card-dark">
            <div className="text-sm text-[#637588] dark:text-[#9da8b9]">
              显示 <span className="font-medium text-[#111418] dark:text-white">{pagination.page === 1 ? 1 : (pagination.page - 1) * pagination.limit + 1}</span> 到{" "}
              <span className="font-medium text-[#111418] dark:text-white">{Math.min(pagination.page * pagination.limit, pagination.total)}</span> 条，共{" "}
              <span className="font-medium text-[#111418] dark:text-white">{pagination.total}</span> 条结果
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={pagination.page === 1}
                className="px-3 py-1 rounded border border-[#e5e7eb] dark:border-[#283545] text-sm font-medium text-[#637588] dark:text-[#9da8b9] bg-white dark:bg-[#101822] hover:bg-[#f3f4f6] dark:hover:bg-[#283545] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                上一页
              </button>
              {Array.from({ length: Math.min(5, pagination.totalPages) }, (_, i) => {
                const pageNum = i + 1;
                return (
                  <button
                    key={pageNum}
                    onClick={() => setPage(pageNum)}
                    className={`px-3 py-1 rounded border text-sm font-medium ${
                      pagination.page === pageNum
                        ? "border-primary bg-primary text-white"
                        : "border-[#e5e7eb] dark:border-[#283545] text-[#637588] dark:text-[#9da8b9] bg-white dark:bg-[#101822] hover:bg-[#f3f4f6] dark:hover:bg-[#283545]"
                    }`}
                  >
                    {pageNum}
                  </button>
                );
              })}
              <button
                onClick={() => setPage((p) => Math.min(pagination.totalPages, p + 1))}
                disabled={pagination.page >= pagination.totalPages}
                className="px-3 py-1 rounded border border-[#e5e7eb] dark:border-[#283545] text-sm font-medium text-[#637588] dark:text-[#9da8b9] bg-white dark:bg-[#101822] hover:bg-[#f3f4f6] dark:hover:bg-[#283545] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                下一页
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
