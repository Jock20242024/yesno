import { NextRequest, NextResponse } from "next/server";
import { verifyAdminToken, createUnauthorizedResponse } from '@/lib/adminAuth';

// 操作类型枚举
type ActionType =
  | "MARKET_CREATE"
  | "MARKET_EDIT"
  | "MARKET_RESOLVE"
  | "WITHDRAWAL_APPROVE"
  | "WITHDRAWAL_REJECT"
  | "USER_DISABLE"
  | "USER_ENABLE"
  | "SETTINGS_UPDATE"
  | "DEPOSIT_VERIFY";

// 模拟操作日志数据
const mockLogs = [
  {
    logId: "LOG-123456",
    adminId: "admin001",
    adminUsername: "admin",
    actionType: "MARKET_CREATE" as ActionType,
    timestamp: "2024-01-15T14:30:25Z",
    details: '创建了新市场："2024年比特币会达到10万美元吗？"',
    relatedObjectId: "MKT-123456",
    relatedObjectType: "market",
  },
  {
    logId: "LOG-123457",
    adminId: "admin001",
    adminUsername: "admin",
    actionType: "WITHDRAWAL_APPROVE" as ActionType,
    timestamp: "2024-01-15T10:15:10Z",
    details: "审批了提现订单 #WD-123456，金额：$1,000.00",
    relatedObjectId: "WD-123456",
    relatedObjectType: "withdrawal",
  },
  {
    logId: "LOG-123458",
    adminId: "admin001",
    adminUsername: "admin",
    actionType: "MARKET_RESOLVE" as ActionType,
    timestamp: "2024-01-14T18:45:30Z",
    details: '结算了市场 "MKT-123450"，结果：YES',
    relatedObjectId: "MKT-123450",
    relatedObjectType: "market",
  },
  {
    logId: "LOG-123459",
    adminId: "admin001",
    adminUsername: "admin",
    actionType: "WITHDRAWAL_REJECT" as ActionType,
    timestamp: "2024-01-13T16:20:15Z",
    details: "拒绝了提现订单 #WD-123459，原因：地址验证失败",
    relatedObjectId: "WD-123459",
    relatedObjectType: "withdrawal",
  },
  {
    logId: "LOG-123460",
    adminId: "admin001",
    adminUsername: "admin",
    actionType: "USER_DISABLE" as ActionType,
    timestamp: "2024-01-12T11:30:45Z",
    details: "禁用了用户账户：user002 (Alice Smith)",
    relatedObjectId: "user002",
    relatedObjectType: "user",
  },
  {
    logId: "LOG-123461",
    adminId: "admin001",
    adminUsername: "admin",
    actionType: "SETTINGS_UPDATE" as ActionType,
    timestamp: "2024-01-11T09:15:20Z",
    details: "更新了系统设置：全局佣金比例从 2.0% 调整为 2.5%",
    relatedObjectId: "settings",
    relatedObjectType: "settings",
  },
  {
    logId: "LOG-123462",
    adminId: "admin001",
    adminUsername: "admin",
    actionType: "MARKET_EDIT" as ActionType,
    timestamp: "2024-01-10T14:20:30Z",
    details: '编辑了市场 "MKT-123445"：更新了截止日期',
    relatedObjectId: "MKT-123445",
    relatedObjectType: "market",
  },
  {
    logId: "LOG-123463",
    adminId: "admin001",
    adminUsername: "admin",
    actionType: "DEPOSIT_VERIFY" as ActionType,
    timestamp: "2024-01-09T13:45:10Z",
    details: "手动验证了充值订单 #DEP-123450，金额：$500.00",
    relatedObjectId: "DEP-123450",
    relatedObjectType: "deposit",
  },
];

export async function GET(request: NextRequest) {
  try {
    // 权限校验：使用统一的 Admin Token 验证函数（从 Cookie 读取）
    const authResult = await verifyAdminToken(request);

    if (!authResult.success) {
      return createUnauthorizedResponse(
        authResult.error || 'Unauthorized. Admin access required.',
        authResult.statusCode || 401
      );
    }

    const { searchParams } = new URL(request.url);
    const searchQuery = searchParams.get("search") || "";
    const adminIdFilter = searchParams.get("adminId") || "";
    const actionTypeFilter = searchParams.get("actionType") || "";
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "10");

    // 过滤数据
    let filteredLogs = [...mockLogs];

    // 按搜索关键词过滤（管理员ID、用户名或详情）
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filteredLogs = filteredLogs.filter(
        (log) =>
          log.logId.toLowerCase().includes(query) ||
          log.adminId.toLowerCase().includes(query) ||
          log.adminUsername.toLowerCase().includes(query) ||
          log.details.toLowerCase().includes(query)
      );
    }

    // 按管理员ID过滤
    if (adminIdFilter) {
      filteredLogs = filteredLogs.filter((log) => log.adminId === adminIdFilter);
    }

    // 按操作类型过滤
    if (actionTypeFilter) {
      filteredLogs = filteredLogs.filter((log) => log.actionType === actionTypeFilter);
    }

    // 按时间倒序排序（最新的在前）
    filteredLogs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    // 分页
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedLogs = filteredLogs.slice(startIndex, endIndex);

    return NextResponse.json({
      success: true,
      data: paginatedLogs,
      pagination: {
        page,
        limit,
        total: filteredLogs.length,
        totalPages: Math.ceil(filteredLogs.length / limit),
      },
    });
  } catch (error) {
    console.error("Admin logs API error:", error);
    return NextResponse.json(
      {
        success: false,
        error: "Internal server error",
      },
      { status: 500 }
    );
  }
}

