# YesNo - Polymarket 仿制应用

一个基于 Next.js 14 构建的预测市场平台，参考 Polymarket 的设计和功能，允许用户对各类事件进行预测和交易。

## 🚀 技术栈

- **框架**: Next.js 14 (App Router)
- **语言**: TypeScript
- **UI 库**: React 18
- **样式**: Tailwind CSS
- **状态管理**: React Context API
- **图标**: Lucide React
- **通知**: Sonner (Toast Notifications)

## ✨ 核心功能

### 已完成功能

- ✅ **市场列表**: 浏览和搜索各类预测市场
- ✅ **市场详情**: 查看市场详细信息、价格图表、订单簿
- ✅ **交易功能**: 买入/卖出 YES/NO 份额，实时价格更新
- ✅ **用户认证**: 登录/注册系统，Token 管理
- ✅ **排行榜**: 用户利润排行榜，支持时间筛选和搜索
- ✅ **个人中心**: 查看个人统计数据、持仓列表、交易历史
- ✅ **用户资料**: 查看其他用户的详细资料和活动记录
- ✅ **市场评论**: 事件评论、持有者列表、规则说明
- ✅ **钱包功能**: 余额管理、持仓查看、资金记录

## 📦 安装指南

### 前置要求

- Node.js 18+ 
- npm 或 yarn

### 安装步骤

1. **克隆仓库**
   ```bash
   git clone https://github.com/Jock20242024/yesno.git
   cd yesno-app
   ```

2. **安装依赖**
   ```bash
   npm install
   ```

3. **启动开发服务器**
   ```bash
   npm run dev
   ```

4. **访问应用**
   
   打开浏览器访问 [http://localhost:3000](http://localhost:3000)

### 其他命令

```bash
# 构建生产版本
npm run build

# 启动生产服务器
npm start

# 运行代码检查
npm run lint
```

## 🏗️ 项目结构

```
yesno-app/
├── app/                    # Next.js App Router 页面
│   ├── api/                # API 路由
│   │   ├── auth/          # 认证相关 API
│   │   ├── markets/       # 市场数据 API
│   │   ├── rankings/     # 排行榜 API
│   │   ├── trade/         # 交易 API
│   │   └── users/         # 用户数据 API
│   ├── markets/           # 市场详情页
│   ├── rank/              # 排行榜页面
│   ├── profile/           # 个人中心
│   └── login/             # 登录页面
├── components/            # React 组件
│   ├── market-detail/    # 市场详情相关组件
│   ├── providers/        # Context Providers
│   └── user/             # 用户相关组件
├── lib/                  # 工具函数和常量
│   ├── mockData.ts       # Mock 数据
│   └── utils.ts          # 工具函数
├── types/                # TypeScript 类型定义
│   └── api.ts            # API 类型定义
└── public/               # 静态资源
```

## 🔌 API 结构

### 市场相关

- `GET /api/markets` - 获取市场列表
  - 查询参数: `category`, `status`, `search`, `page`, `pageSize`
- `GET /api/markets/[market_id]` - 获取单个市场详情

### 交易相关

- `POST /api/trade` - 执行交易
  - 请求体: `{ marketId, outcome, amount, type }`
  - 返回: `{ success, updatedMarketPrice, userPosition }`

### 用户相关

- `GET /api/users/[user_id]` - 获取用户详情
  - 查询参数: `timeRange` (1D, 1W, 1M, ALL)
  - 返回: `{ success, data: { user, tradeHistory, positions } }`

### 排行榜相关

- `GET /api/rankings` - 获取排行榜数据
  - 查询参数: `timeRange`, `search`, `page`, `pageSize`

### 认证相关

- `POST /api/auth/login` - 用户登录
  - 请求体: `{ username, password }`
  - 返回: `{ success, token, user }`
- `POST /api/auth/register` - 用户注册
  - 请求体: `{ username, password, email }`

## 🎨 主要页面

- `/` - 首页（市场列表）
- `/markets/[id]` - 市场详情页
- `/rank` - 排行榜
- `/rank/[user_id]` - 用户资料页
- `/profile` - 个人中心
- `/login` - 登录/注册页
- `/wallet` - 钱包页面

## 🔐 认证系统

项目使用基于 Token 的认证系统：

- 登录成功后，Token 存储在 `localStorage` 中
- 全局状态通过 `AuthProvider` Context 管理
- 受保护的路由会自动检查登录状态

## 📝 开发说明

### 环境变量

在项目根目录创建 `.env.local` 文件（可选）：

```env
# API 配置
NEXT_PUBLIC_API_URL=http://localhost:3000

# 其他环境变量
# ...
```

### Mock 数据

当前项目使用 Mock 数据进行开发和测试，数据存储在 `lib/mockData.ts` 中。

### 类型定义

所有 API 相关的类型定义在 `types/api.ts` 中，包括：
- `Market` - 市场数据
- `User` - 用户数据
- `Activity` - 交易活动
- `Position` - 持仓信息

## 🚧 未来计划

### 短期计划

- [ ] 集成真实的区块链数据源
- [ ] 实现 WebSocket 实时价格更新
- [ ] 添加更多市场筛选和排序选项
- [ ] 优化移动端体验

### 长期计划

- [ ] 集成智能合约（如 Polygon、Arbitrum）
- [ ] 实现去中心化钱包连接（MetaMask、WalletConnect）
- [ ] 添加社交功能（关注、分享、讨论）
- [ ] 实现高级交易功能（限价单、止损等）
- [ ] 多语言支持
- [ ] 暗黑/亮色主题切换

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📄 许可证

本项目仅供学习和研究使用。

## 👥 作者

- 项目维护者: [Jock20242024](https://github.com/Jock20242024)

## 🙏 致谢

- 设计灵感来自 [Polymarket](https://polymarket.com)
- 使用 [Next.js](https://nextjs.org) 和 [Tailwind CSS](https://tailwindcss.com) 构建

---

**注意**: 本项目是 Polymarket 的仿制应用，仅用于学习和演示目的。
