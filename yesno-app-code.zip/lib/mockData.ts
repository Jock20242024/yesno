// 向后兼容：重新导出 DBService
// 注意：此文件已废弃，新代码应直接导入 lib/dbService.ts
export * from './dbService';
