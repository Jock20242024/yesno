-- AlterTable
ALTER TABLE "users" ADD COLUMN     "walletAddress" TEXT;
